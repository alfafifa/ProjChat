import React, { Component } from 'react';
import AppNavigator from './Navigation';

export default class extends Component {

  render() {
    return (
      <AppNavigator />
    );
  }
}