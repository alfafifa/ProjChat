//SERVER ADDRESS
export const API = 'https://chat.blinkpro.co.id/api/';
export const APILOCAL = 'http://localhost/';
export const RTC = 'http://blinkpro.co.id:9001/socket.io/socket.io.js';

export const SERVER = 'http://103.85.14.86/';